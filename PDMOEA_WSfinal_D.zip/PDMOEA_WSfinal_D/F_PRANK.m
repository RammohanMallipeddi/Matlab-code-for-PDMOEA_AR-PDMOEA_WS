function [PRANK,WSRANK] = F_PRANK(Population,FrontValue,NoF)

% Function PRANK assigns priority ranks to each solutions based on the
% Front Value and the Weighted Sum.
% WSRANK is the Weigthed Sum

[N,M] = size(Population);

F = cell(NoF,1);
rd = 1;

PRANK = inf* ones(N,1);
WSRANK = zeros(N,1);


%% Calculation of Weighted Sum and Priority Rank
for i = 1 : NoF
    
    F{i} = find(FrontValue == i);
    fmax          = repmat(max(Population,[],1),N,1);
    fmin          = repmat(min(Population,[],1),N,1);
    Population    = (Population-fmin)./(fmax-fmin);
    
    WSRANK = sum(Population,2);
    
    [~,rank] = sortrows(WSRANK(F{i}));
    
    if size(F{i},2)  <= M
        PRANK(F{i}) = rd;
    else
 %% calculation of the Niche Radius
        
        Distance = zeros(size(F{i},2));
        
        for ii = 1 : (size(F{i},2) - 1)
            for jj = (i + 1) : size(F{i},2)
                Distance(ii,jj) = norm(Population(F{i}(ii),:)-Population(F{i}(jj),:));
                Distance(jj,ii) = Distance(ii,jj);
            end
        end
        
        R = mean(mean(Distance,1),2);
        
 %% Assigning the priority rank to each solution  
        
        Choose = zeros(1,size(F{i},2));
        Remain = ones(1,size(F{i},2));
        XA = length(find(Choose == 0));
        while XA
            for j = rank'
                if Remain(j)
                    for k = 1 : size(F{i},2)
                        if norm(Population(F{i}(j),:)-Population(F{i}(k),:)) <= R
                            Remain(k) = 0;
                        end
                    end
                    Choose(j) = rd;
                end
            end
            rd = rd + 1;
            XA = length(find(Choose == 0));
            Remain(find(Choose==0)) = 1;
            R = R/2;
        end
        PRANK(F{i}) = Choose;
    end
end



