clc;format compact;tic;
% The code of PDMOEA_WS accomplished on MATLAB
% Pareto Dominance-Based Algorithms With Ranking Methods for Many-Objective Optimization
% Vikas Palakonda and Rammohan Mallipeddi
%-----------------------------------------------------------------------------------------
for Problem = 1 : 7   % Problem Selection
    
    for M = 4 : 2 : 10 % number of objectives
        
        % Problem Paramaters
        if Problem == 1 % DTLZ1
            K = 5;  % the parameter in DTLZ1
        elseif Problem == 2 || 3 || 4
            K = 10;  % the parameter in DTLZ2, DTLZ3, DTLZ4,
        elseif Problem == 5 || 6
            K = 10;  % the parameter in DTLZ5, DTLZ6
        elseif Problem == 7 % DTLZ7
            K = 20;  % the parameter in DTLZ7
        end
        
        D = M + K - 1;
        MinValue   = zeros(1,D);
        MaxValue   = ones(1,D);
        Boundary = [MaxValue;MinValue];
        %-----------------------------------------------------------------------------------------
        % Algorithm parameters
        if Problem == 1
            Generations = 700;	 % number of iterations
        elseif Problem == 3
            Generations = 1000;
        else
            Generations = 250;
        end
        
        if M == 2
            N = 100;            % population size
        elseif M == 4
            N = 120;
        elseif M == 6
            N = 132;
        elseif M == 8
            N = 156;
        elseif M == 10
            N = 276;
        end
        Runs = 30;
        %-----------------------------------------------------------------------------------------
        for run = 1 : Runs
            % Initialization
            Population                          = repmat(MinValue,N,1) + repmat(MaxValue - MinValue,N,1).*rand(N,D); % initial population
            FunctionValue                       = F_DTLZ(Population,Problem,M,K);
            [FrontValue,NoF]                    = ENS(FunctionValue,'all');
            PRANK                               = F_PRANK(FunctionValue,FrontValue,NoF);           % non-dominated sort, and return the front number of each solution
            %-----------------------------------------------------------------------------------------
            % start iterations
            for Gene = 1 : Generations
                MatingPool                     = F_mating(Population,FrontValue,PRANK);% mating selection
                Offspring                      = F_operator(MatingPool,Boundary);
                NewFunctionValue               = F_DTLZ(Offspring,Problem,M,K);              % calculate the objective function values
                Population                     = [Population;Offspring];              % combine the two populations
                FunctionValue                  = [FunctionValue;NewFunctionValue];
                [FrontValue,NoF]               = ENS(FunctionValue,'half');
                [PRANK,SRANK]                  = F_PRANK(FunctionValue,FrontValue,NoF);
                
                % Environmental Selection
                [~,Rank]                       = sortrows([FrontValue',PRANK,SRANK]);
                NextPopulation                 = Rank(1:N);
                
                % next population
                Population                     = Population(NextPopulation,:);         	% next population
                FunctionValue                  = FunctionValue(NextPopulation,:);
                FrontValue                     = FrontValue(NextPopulation);              % the front number of each solution in the next population
                SRANK                          = SRANK(NextPopulation);
                PRANK                          = PRANK(NextPopulation);
            end
            F_output (Population,toc,'PDMOEA_ARfinal_D',Problem,M,K,run);
        end
    end
end
