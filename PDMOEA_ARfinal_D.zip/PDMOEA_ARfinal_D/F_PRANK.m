function [PRANK,SRANK] = F_PRANK(Population,FrontValue,NoF)

% Function PRANK assigns priority ranks to each solutions based on the
% Front Value and the SRANK.
% SRANK is the Average Rank

[N,M] = size(Population);

F = cell(NoF,1);

rd = 1;

PRANK = inf* ones(N,1);
SRANK = zeros(N,1);
%% Calculation of Average Rank and Priority Rank
for i = 1 : NoF
    
    F{i} = find(FrontValue == i);
    result = [];
    CS = 1 : M;
    for ii = 1:M
        CS1 = circshift(CS,[1,-(ii-1)]);
        PP = Population(F{i},CS1);
        [~, result(:,ii)] = sortrows(PP);
    end
    
    [~, AAA] = sort(result, 1);      
    
    PRANK(F{i}(result(1,:))) = 1;
    
    
    SRANK(F{i}) = sum(AAA,2);    
    [~,rank] = sortrows(SRANK(F{i}));
    
    if size(F{i},2)  <= M
        
        PRANK(F{i}) = rd;
        
    else
      %% calculation of the Niche Radius  
        
        Distance = zeros(size(F{i},2));
        
        for ii = 1 : (size(F{i},2) - 1)
            for jj = (i + 1) : size(F{i},2)
                Distance(ii,jj) = norm(Population(F{i}(ii),:)-Population(F{i}(jj),:));
                Distance(jj,ii) = Distance(ii,jj);
            end
        end
        
        R = mean(mean(Distance,1),2);
        
     %% Assigning the priority rank to each solution        
        
        Choose = zeros(1,size(F{i},2));
        Remain = ones(1,size(F{i},2));
        XA = length(find(Choose == 0));
        while XA
            for j = rank'
                if Remain(j)
                    for k = 1 : size(F{i},2)
                        if norm(Population(F{i}(j),:)-Population(F{i}(k),:)) <= R
                            Remain(k) = 0;
                        end
                    end
                    Choose(j) = rd;
                end
            end
            rd = rd + 1;
            XA = length(find(Choose == 0));
            Remain(find(Choose==0)) = 1;
            R = R/2;
        end        
        PRANK(F{i}) = Choose;        
    end
end



