function MatingPool = F_mating(Population,FrontValue,PRANK)
% This function is used for the mating selection

    [N,D] = size(Population);
%-----------------------------------------------------------------------------------------     
% Sort the solutions based on their 'FrontValue', and 'PRANK'
    FitnessValue = [FrontValue',PRANK];
    [~,Rank]     = sortrows(FitnessValue);  % the final fitness of each solution (the smaller the better)
    FitnessValue(Rank) = 1:N; 
%-----------------------------------------------------------------------------------------     
% Binary tournament mating selection based on 'FitnessValue'
    Parent1    = randi(N,1,ceil(N/2)*2);
    Parent2    = randi(N,1,ceil(N/2)*2);
    MatingPool = [Parent1(FitnessValue(Parent1)<=FitnessValue(Parent2)),...
                  Parent2(FitnessValue(Parent1)>FitnessValue(Parent2))];
    MatingPool = Population(MatingPool,:);
end

